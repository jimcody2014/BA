# Snarky Motivation Generator
# Requires: httr, jsonlite
# Set your API key first with: Sys.setenv(ANTHROPIC_API_KEY = "your-key-here")

library(httr)
library(jsonlite)

# Get API key from environment
api_key <- Sys.getenv("ANTHROPIC_API_KEY")

if (api_key == "") {
  stop("ANTHROPIC_API_KEY not found in .env file")
}

get_snarky_motivation <- function(topic) {
  prompt <- paste0(
    'Write a snarky, sarcastic motivational statement about "', topic, '". ',
    'It should be exactly 5-6 lines, dripping with dry wit and playful attitude—',
    'but still actually motivating underneath the snark. Think tough love from a ',
    'brutally honest friend. Speak directly to the reader using "you". ',
    'No title, no quotes, no extra formatting—just the motivational lines.'
  )
  
  response <- POST(
    url = "https://api.anthropic.com/v1/messages",
    add_headers(
      "Content-Type" = "application/json",
      "x-api-key" = api_key,
      "anthropic-version" = "2023-06-01"
    ),
    body = toJSON(list(
      model = "claude-sonnet-4-20250514",
      max_tokens = 1000,
      messages = list(
        list(role = "user", content = prompt)
      )
    ), auto_unbox = TRUE),
    encode = "raw"
  )
  
  result <- content(response, as = "parsed")
  
  if (!is.null(result$content)) {
    return(result$content[[1]]$text)
  } else {
    return("Something went wrong. But hey—you're still here, still trying. That counts.")
  }
}

# Main loop
cat("\n========================================\n")
cat("  What do you need a little snarky motivation for?\n")
cat("========================================\n\n")

repeat {
  cat("Enter a topic (or 'quit' to exit): ")
  topic <- readline()
  
  if (tolower(trimws(topic)) == "quit") {
    cat("\nLater. You've got this. Probably.\n")
    break
  }
  
  if (trimws(topic) == "") {
    cat("Come on, give me something to work with.\n\n")
    next
  }
  
  cat("\nFinding the right words...\n\n")
  motivation <- get_snarky_motivation(topic)
  
  cat("--- ", toupper(topic), " ---\n\n", sep = "")
  cat(motivation, "\n\n")
  cat("----------------------------------------\n\n")
}