# ============================================================================
# XGBoost Model for Hospital Readmission Prediction
# Dataset: Diabetic Patient Data (50K records)
# ============================================================================

# ============================================================================
# 1. LOAD REQUIRED LIBRARIES
# ============================================================================

# Install packages if not already installed
required_packages <- c("xgboost", "caret", "dplyr", "tidyr", "pROC")

for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

library(xgboost)
library(caret)
library(dplyr)
library(tidyr)
library(pROC)

cat("All libraries loaded successfully!\n")

# ============================================================================
# 2. LOAD AND INSPECT DATA
# ============================================================================

# Load data from GitHub
url <- "https://raw.githubusercontent.com/jimcody2014/BA/refs/heads/main/diabetic_data50K.csv"
data <- read.csv(url, stringsAsFactors = FALSE)

cat("\n--- Data Dimensions ---\n")
cat("Rows:", nrow(data), "\n")
cat("Columns:", ncol(data), "\n")

cat("\n--- First Few Rows ---\n")
print(head(data))

cat("\n--- Column Names ---\n")
print(colnames(data))

# ============================================================================
# 3. DATA CLEANING - REPLACE '?' WITH NA AND CHECK MISSING VALUES
# ============================================================================

# Replace '?' with NA across all columns
data[data == "?"] <- NA

# Check missing values for each column
cat("\n--- Missing Values Summary ---\n")
missing_summary <- data.frame(
  Column = colnames(data),
  Missing_Count = sapply(data, function(x) sum(is.na(x))),
  Missing_Percent = round(sapply(data, function(x) sum(is.na(x)) / length(x) * 100), 2)
)
missing_summary <- missing_summary[missing_summary$Missing_Count > 0, ]
missing_summary <- missing_summary[order(-missing_summary$Missing_Count), ]
print(missing_summary)

cat("\nTotal missing values in dataset:", sum(is.na(data)), "\n")

# ============================================================================
# 4. REMOVE IDENTIFIER COLUMNS
# ============================================================================

# Remove encounter_id and patient_nbr as they are identifiers
cat("\n--- Removing Identifier Columns ---\n")
cat("Columns before removal:", ncol(data), "\n")

data <- data %>%
  select(-encounter_id, -patient_nbr)

cat("Columns after removal:", ncol(data), "\n")

# ============================================================================
# 5. CREATE TARGET VARIABLES
# ============================================================================

cat("\n--- Creating Target Variables ---\n")

# Check original readmitted values
cat("Original readmitted distribution:\n")
print(table(data$readmitted))

# Binary target: NO=0, readmitted (any)=1
data$target_binary <- ifelse(data$readmitted == "NO", 0, 1)

cat("\nBinary target distribution (NO=0, readmitted=1):\n")
print(table(data$target_binary))

# Multiclass target: NO=0, >30=1, <30=2
data$target_multiclass <- case_when(
  data$readmitted == "NO" ~ 0,
  data$readmitted == ">30" ~ 1,
  data$readmitted == "<30" ~ 2,
  TRUE ~ NA_real_
)

cat("\nMulticlass target distribution (NO=0, >30=1, <30=2):\n")
print(table(data$target_multiclass))

# Remove original readmitted column
data <- data %>% select(-readmitted)

# ============================================================================
# 6. DEFINE CATEGORICAL AND NUMERICAL COLUMNS
# ============================================================================

cat("\n--- Defining Feature Categories ---\n")

# Categorical columns as specified
categorical_cols <- c("race", "gender", "age", "A1Cresult", "insulin", 
                      "diabetesMed", "diag_1", "diag_2", "diag_3")

# Numerical columns as specified
numerical_cols <- c("time_in_hospital", "num_lab_procedures", 
                    "num_procedures", "num_medications")

# Verify columns exist in data
cat("Categorical columns found:", sum(categorical_cols %in% colnames(data)), "/", length(categorical_cols), "\n")
cat("Numerical columns found:", sum(numerical_cols %in% colnames(data)), "/", length(numerical_cols), "\n")

# Show which categorical columns are present
cat("\nCategorical columns in data:\n")
print(categorical_cols[categorical_cols %in% colnames(data)])

cat("\nNumerical columns in data:\n")
print(numerical_cols[numerical_cols %in% colnames(data)])

# ============================================================================
# 7. HANDLE MISSING VALUES IN CATEGORICAL VARIABLES
# ============================================================================

cat("\n--- Replacing NA with 'Unknown' in Categorical Variables ---\n")

# Replace NA with "Unknown" for categorical variables
for (col in categorical_cols) {
  if (col %in% colnames(data)) {
    na_count <- sum(is.na(data[[col]]))
    if (na_count > 0) {
      cat("Column", col, "- replacing", na_count, "NA values with 'Unknown'\n")
      data[[col]][is.na(data[[col]])] <- "Unknown"
    }
  }
}

# Convert categorical columns to factors
for (col in categorical_cols) {
  if (col %in% colnames(data)) {
    data[[col]] <- as.factor(data[[col]])
  }
}

# ============================================================================
# 8. PREPARE FEATURES FOR ONE-HOT ENCODING
# ============================================================================

cat("\n--- Preparing Features for Modeling ---\n")

# Select only the specified categorical and numerical columns plus targets
feature_cols <- c(categorical_cols[categorical_cols %in% colnames(data)], 
                  numerical_cols[numerical_cols %in% colnames(data)])

# Create feature dataframe
features_df <- data[, feature_cols, drop = FALSE]
target_binary <- data$target_binary
target_multiclass <- data$target_multiclass

cat("Number of features selected:", ncol(features_df), "\n")
cat("Features:", paste(colnames(features_df), collapse = ", "), "\n")

# ============================================================================
# 9. ONE-HOT ENCODING USING CARET'S dummyVars
# ============================================================================

cat("\n--- One-Hot Encoding Categorical Variables ---\n")

# Create dummy variables formula
dummy_formula <- as.formula(paste("~", paste(colnames(features_df), collapse = " + ")))

# Create dummyVars object (fullRank=FALSE for all levels)
dummy_model <- dummyVars(dummy_formula, data = features_df, fullRank = FALSE)

# Transform data
features_encoded <- predict(dummy_model, newdata = features_df)
features_encoded <- as.data.frame(features_encoded)

cat("Dimensions before encoding:", nrow(features_df), "x", ncol(features_df), "\n")
cat("Dimensions after encoding:", nrow(features_encoded), "x", ncol(features_encoded), "\n")

cat("\nEncoded feature names (first 20):\n")
print(head(colnames(features_encoded), 20))

# ============================================================================
# 10. IMPUTE REMAINING NA VALUES WITH MEDIAN
# ============================================================================

cat("\n--- Imputing Remaining NA Values with Median ---\n")

# Check for remaining NAs
na_counts <- colSums(is.na(features_encoded))
cols_with_na <- names(na_counts[na_counts > 0])

if (length(cols_with_na) > 0) {
  cat("Columns with remaining NAs:", length(cols_with_na), "\n")
  
  # Impute with median
  for (col in cols_with_na) {
    median_val <- median(features_encoded[[col]], na.rm = TRUE)
    features_encoded[[col]][is.na(features_encoded[[col]])] <- median_val
    cat("Imputed", col, "with median:", median_val, "\n")
  }
} else {
  cat("No remaining NA values to impute.\n")
}

# Final check
cat("Total NAs after imputation:", sum(is.na(features_encoded)), "\n")

# ============================================================================
# 11. TRAIN/TEST SPLIT (80/20) USING createDataPartition
# ============================================================================

cat("\n--- Creating Train/Test Split (80/20) ---\n")

set.seed(42)

# Create partition indices for binary target
train_index <- createDataPartition(target_binary, p = 0.8, list = FALSE)

# Split features
X_train <- features_encoded[train_index, ]
X_test <- features_encoded[-train_index, ]

# Split binary target
y_train_binary <- target_binary[train_index]
y_test_binary <- target_binary[-train_index]

# Split multiclass target (for later use)
y_train_multiclass <- target_multiclass[train_index]
y_test_multiclass <- target_multiclass[-train_index]

cat("Training set size:", nrow(X_train), "\n")
cat("Test set size:", nrow(X_test), "\n")

cat("\nTraining target distribution:\n")
print(table(y_train_binary))
cat("Class proportions:", round(prop.table(table(y_train_binary)) * 100, 2), "%\n")

cat("\nTest target distribution:\n")
print(table(y_test_binary))
cat("Class proportions:", round(prop.table(table(y_test_binary)) * 100, 2), "%\n")

# ============================================================================
# 12. CREATE DMatrix OBJECTS FOR XGBOOST
# ============================================================================

cat("\n--- Creating DMatrix Objects ---\n")

# Convert to matrix format
X_train_matrix <- as.matrix(X_train)
X_test_matrix <- as.matrix(X_test)

# Create DMatrix for training
dtrain <- xgb.DMatrix(data = X_train_matrix, label = y_train_binary)

# Create DMatrix for testing
dtest <- xgb.DMatrix(data = X_test_matrix, label = y_test_binary)

cat("DMatrix objects created successfully!\n")
cat("Training DMatrix dimensions:", nrow(X_train_matrix), "x", ncol(X_train_matrix), "\n")
cat("Test DMatrix dimensions:", nrow(X_test_matrix), "x", ncol(X_test_matrix), "\n")

# ============================================================================
# 13. DEFINE XGBOOST PARAMETERS
# ============================================================================

cat("\n--- Defining XGBoost Parameters ---\n")

params <- list(
  objective = "binary:logistic",  # Binary classification
  eval_metric = "auc",            # Area Under ROC Curve
  max_depth = 6,                  # Maximum tree depth
  eta = 0.1,                      # Learning rate
  subsample = 0.8,                # Row subsampling
  colsample_bytree = 0.8          # Column subsampling per tree
)

cat("XGBoost Parameters:\n")
for (param_name in names(params)) {
  cat(" ", param_name, ":", params[[param_name]], "\n")
}

# ============================================================================
# 14. CROSS-VALIDATION WITH EARLY STOPPING TO FIND OPTIMAL ROUNDS
# ============================================================================

cat("\n--- 5-Fold Cross-Validation with Early Stopping ---\n")

set.seed(42)

cv_results <- xgb.cv(
  params = params,
  data = dtrain,
  nrounds = 500,                  # Maximum number of rounds
  nfold = 5,                      # 5-fold cross-validation
  early_stopping_rounds = 20,     # Stop if no improvement for 20 rounds
  print_every_n = 50,             # Print progress every 50 rounds
  verbose = TRUE
)

# Get optimal number of rounds
optimal_rounds <- cv_results$best_iteration
best_auc <- max(cv_results$evaluation_log$test_auc_mean)

cat("\n--- Cross-Validation Results ---\n")
cat("Optimal number of rounds:", optimal_rounds, "\n")
cat("Best CV AUC:", round(best_auc, 4), "\n")

# Show CV evaluation log (last few entries)
cat("\nCV Evaluation Log (last 10 iterations):\n")
print(tail(cv_results$evaluation_log, 10))

# ============================================================================
# 15. TRAIN FINAL XGBOOST MODEL
# ============================================================================

cat("\n--- Training Final XGBoost Model ---\n")

# Create watchlist for monitoring
watchlist <- list(train = dtrain, test = dtest)

# Train final model with optimal rounds
final_model <- xgb.train(
  params = params,
  data = dtrain,
  nrounds = optimal_rounds,
  watchlist = watchlist,
  print_every_n = 25,
  verbose = TRUE
)

cat("\nFinal model trained with", optimal_rounds, "rounds.\n")

# ============================================================================
# 16. MODEL PREDICTIONS
# ============================================================================

cat("\n--- Generating Predictions ---\n")

# Predict probabilities on test set
y_pred_prob <- predict(final_model, dtest)

# Convert to binary predictions using 0.5 threshold
y_pred_binary <- ifelse(y_pred_prob >= 0.5, 1, 0)

cat("Prediction summary:\n")
cat("Min probability:", round(min(y_pred_prob), 4), "\n")
cat("Max probability:", round(max(y_pred_prob), 4), "\n")
cat("Mean probability:", round(mean(y_pred_prob), 4), "\n")

# ============================================================================
# 17. MODEL EVALUATION - CONFUSION MATRIX
# ============================================================================

cat("\n--- Confusion Matrix ---\n")

# Create confusion matrix using caret
conf_matrix <- confusionMatrix(
  as.factor(y_pred_binary), 
  as.factor(y_test_binary),
  positive = "1"
)

print(conf_matrix)

# Extract key metrics
accuracy <- conf_matrix$overall["Accuracy"]
sensitivity <- conf_matrix$byClass["Sensitivity"]
specificity <- conf_matrix$byClass["Specificity"]
precision <- conf_matrix$byClass["Pos Pred Value"]
f1_score <- conf_matrix$byClass["F1"]

cat("\n--- Key Performance Metrics ---\n")
cat("Accuracy:", round(accuracy, 4), "\n")
cat("Sensitivity (Recall):", round(sensitivity, 4), "\n")
cat("Specificity:", round(specificity, 4), "\n")
cat("Precision:", round(precision, 4), "\n")
cat("F1 Score:", round(f1_score, 4), "\n")

# ============================================================================
# 18. ROC CURVE AND AUC
# ============================================================================

cat("\n--- ROC Curve and AUC ---\n")

# Calculate ROC curve
roc_obj <- roc(y_test_binary, y_pred_prob)

# Get AUC
auc_value <- auc(roc_obj)
cat("Test Set AUC:", round(auc_value, 4), "\n")

# Plot ROC curve
png("roc_curve.png", width = 800, height = 600)
plot(roc_obj, 
     main = "ROC Curve - XGBoost Hospital Readmission Prediction",
     col = "blue", 
     lwd = 2,
     print.auc = TRUE,
     print.auc.x = 0.4,
     print.auc.y = 0.2,
     legacy.axes = TRUE)

# Add diagonal reference line
abline(a = 0, b = 1, lty = 2, col = "gray")

# Add grid
grid()

dev.off()
cat("ROC curve saved to 'roc_curve.png'\n")

# Also display AUC confidence interval
cat("\nAUC 95% Confidence Interval:\n")
ci_auc <- ci.auc(roc_obj)
print(ci_auc)

# ============================================================================
# 19. FEATURE IMPORTANCE - TOP 20 FEATURES
# ============================================================================

cat("\n--- Feature Importance (Top 20) ---\n")

# Get feature importance
importance_matrix <- xgb.importance(
  feature_names = colnames(X_train_matrix),
  model = final_model
)

# Show top 20 features
cat("\nTop 20 Most Important Features:\n")
print(head(importance_matrix, 20))

# Plot feature importance (top 20)
png("feature_importance.png", width = 1000, height = 800)
xgb.plot.importance(
  importance_matrix[1:min(20, nrow(importance_matrix)), ],
  main = "XGBoost Feature Importance (Top 20)",
  xlab = "Importance (Gain)"
)
dev.off()
cat("\nFeature importance plot saved to 'feature_importance.png'\n")

# Alternative importance plot with ggplot2 style
png("feature_importance_bar.png", width = 1000, height = 800)
par(mar = c(5, 12, 4, 2))
top_20 <- head(importance_matrix, 20)
barplot(
  rev(top_20$Gain),
  names.arg = rev(top_20$Feature),
  horiz = TRUE,
  las = 1,
  main = "Top 20 Feature Importance by Gain",
  xlab = "Gain",
  col = "steelblue",
  border = NA
)
dev.off()
cat("Bar plot saved to 'feature_importance_bar.png'\n")

# ============================================================================
# 20. HYPERPARAMETER GRID SEARCH
# ============================================================================

cat("\n" , paste(rep("=", 60), collapse = ""), "\n")
cat("HYPERPARAMETER GRID SEARCH SECTION\n")
cat(paste(rep("=", 60), collapse = ""), "\n")

# Define hyperparameter grid
param_grid <- expand.grid(
  max_depth = c(4, 6, 8),
  eta = c(0.05, 0.1, 0.2),
  subsample = c(0.7, 0.8, 0.9),
  colsample_bytree = c(0.7, 0.8, 0.9)
)

cat("\nGrid Search Configuration:\n")
cat("Total parameter combinations:", nrow(param_grid), "\n")
cat("Parameters being tuned:\n")
cat("  - max_depth:", unique(param_grid$max_depth), "\n")
cat("  - eta:", unique(param_grid$eta), "\n")
cat("  - subsample:", unique(param_grid$subsample), "\n")
cat("  - colsample_bytree:", unique(param_grid$colsample_bytree), "\n")

# Initialize results storage
grid_search_results <- data.frame(
  max_depth = numeric(),
  eta = numeric(),
  subsample = numeric(),
  colsample_bytree = numeric(),
  best_iteration = numeric(),
  train_auc = numeric(),
  test_auc = numeric()
)

# Run grid search (reduced for demonstration - uncomment full loop for production)
cat("\nRunning Grid Search (this may take a while)...\n")

# For demonstration, run on subset of grid
# In production, use: for (i in 1:nrow(param_grid))
demo_indices <- c(1, 5, 10, 15, 20)  # Sample of parameter combinations
demo_indices <- demo_indices[demo_indices <= nrow(param_grid)]

for (i in demo_indices) {
  current_params <- list(
    objective = "binary:logistic",
    eval_metric = "auc",
    max_depth = param_grid$max_depth[i],
    eta = param_grid$eta[i],
    subsample = param_grid$subsample[i],
    colsample_bytree = param_grid$colsample_bytree[i]
  )
  
  # Run cross-validation
  set.seed(42)
  cv_result <- xgb.cv(
    params = current_params,
    data = dtrain,
    nrounds = 200,
    nfold = 5,
    early_stopping_rounds = 15,
    verbose = FALSE
  )
  
  # Store results
  result_row <- data.frame(
    max_depth = param_grid$max_depth[i],
    eta = param_grid$eta[i],
    subsample = param_grid$subsample[i],
    colsample_bytree = param_grid$colsample_bytree[i],
    best_iteration = cv_result$best_iteration,
    train_auc = max(cv_result$evaluation_log$train_auc_mean),
    test_auc = max(cv_result$evaluation_log$test_auc_mean)
  )
  
  grid_search_results <- rbind(grid_search_results, result_row)
  
  cat(sprintf("Combo %d: max_depth=%d, eta=%.2f, subsample=%.1f, colsample=%.1f -> AUC=%.4f\n",
              i, current_params$max_depth, current_params$eta, 
              current_params$subsample, current_params$colsample_bytree,
              max(cv_result$evaluation_log$test_auc_mean)))
}

# Sort by test AUC
grid_search_results <- grid_search_results[order(-grid_search_results$test_auc), ]

cat("\n--- Grid Search Results (Top 5) ---\n")
print(head(grid_search_results, 5))

# Best parameters
best_params <- grid_search_results[1, ]
cat("\nBest Parameters Found:\n")
cat("  max_depth:", best_params$max_depth, "\n")
cat("  eta:", best_params$eta, "\n")
cat("  subsample:", best_params$subsample, "\n")
cat("  colsample_bytree:", best_params$colsample_bytree, "\n")
cat("  Best CV AUC:", round(best_params$test_auc, 4), "\n")

# ============================================================================
# 21. MULTICLASS CLASSIFICATION VERSION (COMMENTED OUT)
# ============================================================================

# # -------------------------------------------------------------------------
# # MULTICLASS XGBOOST MODEL
# # Target: NO=0, >30=1, <30=2
# # -------------------------------------------------------------------------
# 
# cat("\n--- Multiclass XGBoost Model ---\n")
# 
# # Create DMatrix for multiclass
# dtrain_multi <- xgb.DMatrix(data = X_train_matrix, label = y_train_multiclass)
# dtest_multi <- xgb.DMatrix(data = X_test_matrix, label = y_test_multiclass)
# 
# # Multiclass parameters
# params_multi <- list(
#   objective = "multi:softprob",   # Multiclass with probability output
#   eval_metric = "mlogloss",       # Multiclass log loss
#   num_class = 3,                  # Number of classes (0, 1, 2)
#   max_depth = 6,
#   eta = 0.1,
#   subsample = 0.8,
#   colsample_bytree = 0.8
# )
# 
# # Cross-validation for multiclass
# set.seed(42)
# cv_multi <- xgb.cv(
#   params = params_multi,
#   data = dtrain_multi,
#   nrounds = 500,
#   nfold = 5,
#   early_stopping_rounds = 20,
#   print_every_n = 50,
#   verbose = TRUE
# )
# 
# optimal_rounds_multi <- cv_multi$best_iteration
# cat("Optimal rounds for multiclass:", optimal_rounds_multi, "\n")
# 
# # Train multiclass model
# watchlist_multi <- list(train = dtrain_multi, test = dtest_multi)
# 
# model_multi <- xgb.train(
#   params = params_multi,
#   data = dtrain_multi,
#   nrounds = optimal_rounds_multi,
#   watchlist = watchlist_multi,
#   print_every_n = 25,
#   verbose = TRUE
# )
# 
# # Predict probabilities (returns matrix with 3 columns)
# pred_probs_multi <- predict(model_multi, dtest_multi, reshape = TRUE)
# colnames(pred_probs_multi) <- c("NO", ">30", "<30")
# 
# # Get predicted classes
# pred_class_multi <- apply(pred_probs_multi, 1, which.max) - 1
# 
# # Confusion matrix for multiclass
# cat("\nMulticlass Confusion Matrix:\n")
# conf_matrix_multi <- confusionMatrix(
#   as.factor(pred_class_multi),
#   as.factor(y_test_multiclass)
# )
# print(conf_matrix_multi)
# 
# # Per-class metrics
# cat("\nPer-Class Metrics:\n")
# print(conf_matrix_multi$byClass)
# 
# # Multiclass AUC (one-vs-rest)
# cat("\nMulticlass AUC (One-vs-Rest):\n")
# for (class_idx in 0:2) {
#   class_labels <- ifelse(y_test_multiclass == class_idx, 1, 0)
#   class_probs <- pred_probs_multi[, class_idx + 1]
#   roc_class <- roc(class_labels, class_probs)
#   cat(sprintf("  Class %d AUC: %.4f\n", class_idx, auc(roc_class)))
# }
# 
# # Save multiclass model
# xgb.save(model_multi, "xgboost_multiclass_model.model")
# cat("\nMulticlass model saved to 'xgboost_multiclass_model.model'\n")

# ============================================================================
# 22. SAVE FINAL MODEL
# ============================================================================

cat("\n--- Saving Final Model ---\n")

# Save in XGBoost native format
model_path <- "xgboost_binary_model.model"
xgb.save(final_model, model_path)
cat("Model saved to:", model_path, "\n")

# Save as RDS (R native format for full object)
rds_path <- "xgboost_binary_model.rds"
saveRDS(final_model, rds_path)
cat("Model also saved as RDS to:", rds_path, "\n")

# Save feature names for later use
feature_names_path <- "feature_names.rds"
saveRDS(colnames(X_train_matrix), feature_names_path)
cat("Feature names saved to:", feature_names_path, "\n")

# ============================================================================
# 23. MODEL SUMMARY AND FINAL REPORT
# ============================================================================

cat("\n")
cat(paste(rep("=", 70), collapse = ""), "\n")
cat("                    FINAL MODEL SUMMARY REPORT\n")
cat(paste(rep("=", 70), collapse = ""), "\n")

cat("\n--- Dataset Information ---\n")
cat("Total samples:", nrow(data), "\n")
cat("Training samples:", nrow(X_train), "\n")
cat("Test samples:", nrow(X_test), "\n")
cat("Number of features (after encoding):", ncol(X_train), "\n")

cat("\n--- Model Configuration ---\n")
cat("Algorithm: XGBoost (Gradient Boosting)\n")
cat("Objective: binary:logistic\n")
cat("Evaluation Metric: AUC\n")
cat("Optimal Rounds:", optimal_rounds, "\n")
cat("Max Depth:", params$max_depth, "\n")
cat("Learning Rate (eta):", params$eta, "\n")
cat("Subsample:", params$subsample, "\n")
cat("Colsample by Tree:", params$colsample_bytree, "\n")

cat("\n--- Performance Metrics ---\n")
cat("Cross-Validation AUC:", round(best_auc, 4), "\n")
cat("Test Set AUC:", round(as.numeric(auc_value), 4), "\n")
cat("Test Set Accuracy:", round(as.numeric(accuracy), 4), "\n")
cat("Test Set Sensitivity:", round(as.numeric(sensitivity), 4), "\n")
cat("Test Set Specificity:", round(as.numeric(specificity), 4), "\n")
cat("Test Set Precision:", round(as.numeric(precision), 4), "\n")
cat("Test Set F1 Score:", round(as.numeric(f1_score), 4), "\n")

cat("\n--- Top 5 Most Important Features ---\n")
print(head(importance_matrix[, c("Feature", "Gain", "Cover", "Frequency")], 5))

cat("\n--- Files Created ---\n")
cat("1. xgboost_binary_model.model (XGBoost native format)\n")
cat("2. xgboost_binary_model.rds (R object format)\n")
cat("3. feature_names.rds (Feature names for inference)\n")
cat("4. roc_curve.png (ROC curve visualization)\n")
cat("5. feature_importance.png (Feature importance plot)\n")
cat("6. feature_importance_bar.png (Bar chart of importance)\n")

cat("\n")
cat(paste(rep("=", 70), collapse = ""), "\n")
cat("                    MODEL TRAINING COMPLETE!\n")
cat(paste(rep("=", 70), collapse = ""), "\n")

# ============================================================================
# 24. EXAMPLE: HOW TO LOAD AND USE THE SAVED MODEL
# ============================================================================

# # Load the saved model
# loaded_model <- xgb.load("xgboost_binary_model.model")
# # OR
# loaded_model <- readRDS("xgboost_binary_model.rds")
# 
# # Load feature names
# feature_names <- readRDS("feature_names.rds")
# 
# # Prepare new data (must match training preprocessing)
# # new_data_matrix <- as.matrix(new_data_encoded)
# # new_dmatrix <- xgb.DMatrix(data = new_data_matrix)
# 
# # Make predictions
# # predictions <- predict(loaded_model, new_dmatrix)
# # predicted_class <- ifelse(predictions >= 0.5, 1, 0)