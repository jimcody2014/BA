# Snarky Motivation Generator - Shiny App
# Requires: shiny, shinyjs, httr, jsonlite
# Set your API key first with: Sys.setenv(ANTHROPIC_API_KEY = "your-key-here")

library(shiny)
library(shinyjs)
library(httr)
library(jsonlite)

# Get API key from environment
api_key <- Sys.getenv("ANTHROPIC_API_KEY")

if (api_key == "") {
  stop("ANTHROPIC_API_KEY not found. Set it with: Sys.setenv(ANTHROPIC_API_KEY = 'your-key-here')")
}

get_snarky_motivation <- function(topic) {
  prompt <- paste0(
    'Write a snarky, sarcastic motivational statement about "', topic, '". ',
    'It should be exactly 5-6 lines, dripping with dry wit and playful attitude—',
    'but still actually motivating underneath the snark. Think tough love from a ',
    'brutally honest friend. Speak directly to the reader using "you". ',
    'No title, no quotes, no extra formatting—just the motivational lines.'
  )
  
  response <- POST(
    url = "https://api.anthropic.com/v1/messages",
    add_headers(
      "Content-Type" = "application/json",
      "x-api-key" = api_key,
      "anthropic-version" = "2023-06-01"
    ),
    body = toJSON(list(
      model = "claude-sonnet-4-20250514",
      max_tokens = 1000,
      messages = list(
        list(role = "user", content = prompt)
      )
    ), auto_unbox = TRUE),
    encode = "raw"
  )
  
  result <- content(response, as = "parsed")
  
  if (!is.null(result$content)) {
    return(result$content[[1]]$text)
  } else {
    return("Something went wrong. But hey—you're still here, still trying. That counts.")
  }
}

ui <- fluidPage(
  useShinyjs(),
  tags$head(
    tags$style(HTML("
      body {
        background: linear-gradient(135deg, #1e293b 0%, #334155 50%, #1e293b 100%);
        min-height: 100vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }
      .container-fluid {
        padding-top: 80px;
      }
      .main-card {
        background: rgba(51, 65, 85, 0.5);
        border: 1px solid rgba(71, 85, 105, 0.5);
        border-radius: 16px;
        padding: 40px;
        max-width: 600px;
        margin: 0 auto;
        text-align: center;
      }
      .title {
        color: white;
        font-size: 28px;
        font-weight: 300;
        margin-bottom: 8px;
      }
      .subtitle {
        color: #94a3b8;
        font-size: 14px;
        margin-bottom: 30px;
      }
      .topic-input {
        width: 100%;
        padding: 16px 24px;
        background: rgba(30, 41, 59, 0.5);
        border: 1px solid #475569;
        border-radius: 12px;
        color: white;
        font-size: 18px;
        text-align: center;
        margin-bottom: 20px;
      }
      .topic-input:focus {
        outline: none;
        border-color: #f59e0b;
        box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.2);
      }
      .topic-input::placeholder {
        color: #64748b;
      }
      .btn-motivate {
        background: #f59e0b;
        color: #1e293b;
        border: none;
        padding: 12px 32px;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.2s;
      }
      .btn-motivate:hover {
        background: #fbbf24;
      }
      .btn-motivate:disabled {
        background: #475569;
        color: #64748b;
        cursor: not-allowed;
      }
      .result-card {
        background: rgba(30, 41, 59, 0.3);
        border: 1px solid rgba(71, 85, 105, 0.5);
        border-radius: 16px;
        padding: 32px;
        margin-top: 30px;
        text-align: center;
      }
      .topic-label {
        color: #f59e0b;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 2px;
        margin-bottom: 16px;
      }
      .motivation-text {
        color: white;
        font-size: 20px;
        line-height: 1.6;
        font-weight: 300;
        white-space: pre-line;
      }
      .btn-reset {
        background: transparent;
        color: #94a3b8;
        border: 1px solid #475569;
        padding: 8px 24px;
        border-radius: 8px;
        font-size: 14px;
        cursor: pointer;
        margin-top: 24px;
        transition: all 0.2s;
      }
      .btn-reset:hover {
        color: white;
        border-color: #64748b;
      }
      .loading {
        color: #94a3b8;
        font-style: italic;
      }
      .spinner {
        width: 40px;
        height: 40px;
        border: 3px solid rgba(245, 158, 11, 0.3);
        border-top-color: #f59e0b;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto 16px auto;
      }
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
    "))
  ),
  
  div(class = "main-card",
      div(class = "title", "What do you need a little snarky motivation for?"),
      div(class = "subtitle", "Type a topic below"),
      
      textInput("topic", label = NULL, placeholder = "e.g., waking up, starting over, finishing a project..."),
      
      actionButton("generate", "Give me motivation", class = "btn-motivate"),
      
      # Loading indicator (hidden by default)
      hidden(
        div(id = "loading_div", class = "result-card",
            div(class = "spinner"),
            p(class = "loading", "Finding the right words...")
        )
      ),
      
      # Result display (hidden by default)
      hidden(
        div(id = "result_div", class = "result-card",
            div(id = "topic_label", class = "topic-label"),
            div(id = "motivation_text", class = "motivation-text"),
            actionButton("reset", "Try another topic", class = "btn-reset")
        )
      )
  ),
  
  tags$script(HTML("
    $(document).ready(function() {
      $('#topic').addClass('topic-input');
      $('#topic').on('keypress', function(e) {
        if (e.which == 13) {
          $('#generate').click();
        }
      });
    });
  "))
)

server <- function(input, output, session) {
  
  observeEvent(input$generate, {
    req(input$topic)
    if (trimws(input$topic) == "") return()
    
    # Show loading, hide result
    hide("result_div")
    show("loading_div")
    
    # Use delay to allow UI to update before blocking API call
    delay(100, {
      result <- get_snarky_motivation(input$topic)
      
      # Update result content using shinyjs::html
      html("topic_label", toupper(input$topic))
      html("motivation_text", gsub("\n", "<br>", result))
      
      # Hide loading, show result
      hide("loading_div")
      show("result_div")
    })
  })
  
  observeEvent(input$reset, {
    hide("result_div")
    updateTextInput(session, "topic", value = "")
  })
}

shinyApp(ui = ui, server = server)