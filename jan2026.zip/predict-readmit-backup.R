# XGBoost Model for Readmission Prediction
# Required packages: tidyverse, caret, xgboost

# Install packages if needed (uncomment if necessary)
# install.packages(c("tidyverse", "caret", "xgboost"))

library(tidyverse)
library(caret)
library(xgboost)

cat("============================================================\n")
cat("LOADING AND PREPARING DATA\n")
cat("============================================================\n")

# Load data from URL
url <- "https://raw.githubusercontent.com/jimcody2014/BA/refs/heads/main/diabetic_data50K.csv"
df <- read.csv(url, stringsAsFactors = FALSE)
cat(sprintf("Dataset shape: %d rows, %d columns\n", nrow(df), ncol(df)))

# Drop identifier columns
df <- df %>% select(-encounter_id, -patient_nbr)
cat(sprintf("After dropping IDs: %d rows, %d columns\n", nrow(df), ncol(df)))

# Create binary target variable (1 = readmitted, 0 = not readmitted)
df <- df %>%
  mutate(readmitted_binary = ifelse(readmitted %in% c("<30", ">30"), 1, 0)) %>%
  select(-readmitted)

cat("\nTarget variable distribution:\n")
cat(sprintf("  0 (NO):  %d\n", sum(df$readmitted_binary == 0)))
cat(sprintf("  1 (YES): %d\n", sum(df$readmitted_binary == 1)))

# Handle missing values (replace '?' with 'Unknown')
df[df == "?"] <- "Unknown"

# Convert categorical columns to factors, then to numeric for XGBoost
categorical_cols <- names(df)[sapply(df, is.character)]
for (col in categorical_cols) {
  df[[col]] <- as.numeric(as.factor(df[[col]]))
}

cat(sprintf("\nEncoded %d categorical columns\n", length(categorical_cols)))

# Separate features and target
X <- df %>% select(-readmitted_binary)
y <- df$readmitted_binary

# Split data (80% train, 20% test)
set.seed(42)
train_index <- createDataPartition(y, p = 0.8, list = FALSE)
X_train <- X[train_index, ]
X_test <- X[-train_index, ]
y_train <- y[train_index]
y_test <- y[-train_index]

cat(sprintf("\nTrain set: %d rows\n", nrow(X_train)))
cat(sprintf("Test set:  %d rows\n", nrow(X_test)))

cat("\n============================================================\n")
cat("TRAINING XGBOOST MODEL\n")
cat("============================================================\n")

# Convert to XGBoost matrix format
dtrain <- xgb.DMatrix(data = as.matrix(X_train), label = y_train)
dtest <- xgb.DMatrix(data = as.matrix(X_test), label = y_test)

# Set parameters
params <- list(
  objective = "binary:logistic",
  eval_metric = "logloss",
  max_depth = 6,
  eta = 0.3
)

# Train model
model <- xgb.train(
  params = params,
  data = dtrain,
  nrounds = 100,
  verbose = 0
)
cat("Model trained successfully!\n")

# Make predictions
predicted_probs <- predict(model, dtest)
predicted_class <- ifelse(predicted_probs > 0.5, 1, 0)

cat("\n============================================================\n")
cat("MODEL PERFORMANCE\n")
cat("============================================================\n")

# Calculate metrics
accuracy <- mean(predicted_class == y_test)

# Precision: TP / (TP + FP)
true_positives <- sum(predicted_class == 1 & y_test == 1)
false_positives <- sum(predicted_class == 1 & y_test == 0)
precision <- true_positives / (true_positives + false_positives)

# Recall: TP / (TP + FN)
false_negatives <- sum(predicted_class == 0 & y_test == 1)
recall <- true_positives / (true_positives + false_negatives)

# True negatives
true_negatives <- sum(predicted_class == 0 & y_test == 0)

cat(sprintf("\nAccuracy:  %.4f (%.1f%%)\n", accuracy, accuracy * 100))
cat(sprintf("Precision: %.4f (%.1f%%)\n", precision, precision * 100))
cat(sprintf("Recall:    %.4f (%.1f%%)\n", recall, recall * 100))

# Confusion matrix
cat("\nConfusion Matrix:\n")
cat("                 Predicted NO   Predicted YES\n")
cat(sprintf("  Actual NO      %8d       %8d\n", true_negatives, false_positives))
cat(sprintf("  Actual YES     %8d       %8d\n", false_negatives, true_positives))

cat("\n============================================================\n")
cat("INTERPRETATION\n")
cat("============================================================\n")
cat(sprintf("\n- Accuracy (%.1f%%): The model correctly predicts %.1f%% of all cases.\n", 
            accuracy * 100, accuracy * 100))
cat(sprintf("- Precision (%.1f%%): When the model predicts readmission, it's correct %.1f%% of the time.\n", 
            precision * 100, precision * 100))
cat(sprintf("- Recall (%.1f%%): The model catches %.1f%% of actual readmissions.\n", 
            recall * 100, recall * 100))

cat("\n============================================================\n")
cat("FEATURE IMPORTANCE (Top 10)\n")
cat("============================================================\n")
importance <- xgb.importance(model = model)
print(head(importance, 10))