# Load the data from URL
url <- "https://raw.githubusercontent.com/jimcody2014/BA/refs/heads/main/diabetic_data50K.csv"
df <- read.csv(url)

# ============================================
# DATASET OVERVIEW
# ============================================
cat("DATASET OVERVIEW\n")
cat("================\n")
cat("Records:", nrow(df), "\n")
cat("Variables:", ncol(df), "\n\n")
cat("Column Names:\n")
print(names(df))

# ============================================
# SUMMARY STATISTICS
# ============================================
cat("\n\nSUMMARY STATISTICS\n")
cat("==================\n\n")

# Define the numeric variables of interest
numeric_vars <- c("time_in_hospital", "num_lab_procedures", "num_procedures", "num_medications")

# Calculate statistics
summary_stats <- data.frame(
  Metric = c("Min", "Max", "Mean"),
  Time_in_Hospital = c(
    min(df$time_in_hospital, na.rm = TRUE),
    max(df$time_in_hospital, na.rm = TRUE),
    round(mean(df$time_in_hospital, na.rm = TRUE), 2)
  ),
  Num_Lab_Procedures = c(
    min(df$num_lab_procedures, na.rm = TRUE),
    max(df$num_lab_procedures, na.rm = TRUE),
    round(mean(df$num_lab_procedures, na.rm = TRUE), 2)
  ),
  Num_Procedures = c(
    min(df$num_procedures, na.rm = TRUE),
    max(df$num_procedures, na.rm = TRUE),
    round(mean(df$num_procedures, na.rm = TRUE), 2)
  ),
  Num_Medications = c(
    min(df$num_medications, na.rm = TRUE),
    max(df$num_medications, na.rm = TRUE),
    round(mean(df$num_medications, na.rm = TRUE), 2)
  )
)

# Display the summary table
print(summary_stats)